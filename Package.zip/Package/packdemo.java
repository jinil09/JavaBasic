package Pack1;   //Semi collen is requied
import pack2.*;  // import pack syntex

class packdemo
{
	public static void main(String args[])
	{
		System.out.println("Hello....Package");
		
		importpack obj=new importpack();  //Call pack 2 public class 
		obj.show();                       //call method
	}
}

// Compile code = javac -d . filename.java
// Here '.' is show Defult path of file / 'diractoryname' is show coustom path 

// Run time code = java packagename.javafilename