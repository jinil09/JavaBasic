package pack2;

public class importpack
{
	public void show()
	{
		System.out.println("Hello import java");
	}
}