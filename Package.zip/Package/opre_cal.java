package Operation;
import java.util.*;

public class opre_cal
{
	float a,b,c;
	
	public void Addition()
	{
		System.out.println("Enter First value :");
	    Scanner jp=new Scanner(System.in);
		a=jp.nextFloat();
		
		System.out.println("Enter Second Value :");
		Scanner jp1=new Scanner(System.in);
		b=jp1.nextFloat();
	
		
     	c=a+b;
		
		System.out.println("Here is Your ANS : "+c);
	}
	
	public void Substraction()
	{
		System.out.println("Enter First value :");
	    Scanner jp=new Scanner(System.in);
		a=jp.nextFloat();
		
		System.out.println("Enter Second Value :");
		Scanner jp1=new Scanner(System.in);
		b=jp1.nextFloat();
	
		
     	c=a-b;
		
		System.out.println("Here is Your ANS : "+c);
	}
	
	public void division()
	{
		System.out.println("Enter First value :");
	    Scanner jp=new Scanner(System.in);
		a=jp.nextFloat();
		
		System.out.println("Enter Second Value :");
		Scanner jp1=new Scanner(System.in);
		b=jp1.nextFloat();
	
		
     	c=a/b;
		
		System.out.println("Here is Your ANS : "+c);
	}
	
	public void multi()
	{
		System.out.println("Enter First value :");
	    Scanner jp=new Scanner(System.in);
		a=jp.nextFloat();
		
		System.out.println("Enter Second Value :");
		Scanner jp1=new Scanner(System.in);
		b=jp1.nextFloat();
	
		
     	c=a*b;
		
		System.out.println("Here is Your ANS : "+c);
	}
}