package Calculetor;
import Operation.*;
import java.util.*;

class caldemo
{
	public static void main(String args[])
	{
		int i;
		System.out.println("----------------------");
		System.out.println("1 = Addition(+)");
		System.out.println("2 = Substraction(-)");
		System.out.println("3 = Division(/)");
		System.out.println("4 = Multiplication(*)");
		System.out.println("----------------------");
		
		System.out.println("Enter your choise");
		
		Scanner jp=new Scanner(System.in);
		i=jp.nextInt();
		
		switch(i)
		{
			case 1:
			{
				opre_cal obj=new opre_cal();
				obj.Addition();
			}break;
			
			case 2:
			{
				opre_cal obj=new opre_cal();
				obj.Substraction();
			}break;
			
			case 3:
			{
				opre_cal obj=new opre_cal();
				obj.division();
			}break;
			
			case 4:
			{
				opre_cal obj=new opre_cal();
				obj.multi();
			}break;
			
			default:
			{
				System.out.println("PLEASE ENTER VALID CHOISE");
			}
			
		}
	}
}

